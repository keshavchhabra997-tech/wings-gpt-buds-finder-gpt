package com.wingsgpt.buds.ble

class RssiSmoother(private val windowSize: Int = 5) {
    private val samples = ArrayDeque<Int>()
    init { require(windowSize > 0) }

    fun add(value: Int): Int {
        samples.addLast(value)
        while (samples.size > windowSize) samples.removeFirst()
        return samples.average().toInt()
    }

    fun reset() = samples.clear()
    fun snapshot(): List<Int> = samples.toList()
}

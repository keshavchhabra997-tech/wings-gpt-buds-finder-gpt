package com.wingsgpt.buds.ble

import com.wingsgpt.buds.model.BleObservation
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

class BleRepository(private val scanner: BleScanner) {
    fun observations(): Flow<BleObservation> = scanner.scan()
        .map { it.copy(name = it.name.trim().ifBlank { "Unknown device" }) }
    fun available(): Boolean = scanner.isBleSupported() && scanner.isBluetoothAvailable()
}

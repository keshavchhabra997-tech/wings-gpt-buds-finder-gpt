package com.wingsgpt.buds.ui.theme

import androidx.compose.ui.graphics.Color

val Void = Color(0xFF050609)
val Panel = Color(0xFF11151D)
val Glass = Color(0xAA252B38)
val GlassEdge = Color(0x55FFFFFF)
val Cyan = Color(0xFF74E8FF)
val Blue = Color(0xFF657BFF)
val Violet = Color(0xFFB27BFF)
val Muted = Color(0xFF8B93A5)
val TextPrimary = Color(0xFFF5F7FC)
val Good = Color(0xFF78E0B2)
val Warning = Color(0xFFFFC978)
val Danger = Color(0xFFFF7385)

package com.wingsgpt.buds.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wingsgpt.buds.ble.BleRepository
import com.wingsgpt.buds.ble.BleScanner
import com.wingsgpt.buds.ble.RssiSmoother
import com.wingsgpt.buds.model.BleObservation
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DashboardState(
    val scanning: Boolean = false,
    val observations: List<BleObservation> = emptyList(),
    val selectedAddress: String? = null,
    val error: String? = null,
    val bluetoothAvailable: Boolean = false
)

class WingsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = BleRepository(BleScanner(application))
    private val smoother = RssiSmoother(7)
    private val _state = MutableStateFlow(DashboardState(bluetoothAvailable = repository.available()))
    val state: StateFlow<DashboardState> = _state.asStateFlow()
    private var scanJob: Job? = null

    fun startScan() {
        if (scanJob?.isActive == true) return
        _state.value = _state.value.copy(scanning = true, error = null)
        scanJob = viewModelScope.launch {
            try {
                repository.observations().collect { item ->
                    val current = _state.value.observations.toMutableList()
                    val index = current.indexOfFirst { it.address == item.address }
                    val smoothed = smoother.add(item.rssi)
                    val display = item.copy(rssi = smoothed)
                    if (index >= 0) current[index] = display else current.add(display)
                    _state.value = _state.value.copy(
                        observations = current.sortedByDescending { it.rssi }.take(60),
                        bluetoothAvailable = true
                    )
                }
            } catch (error: Exception) {
                _state.value = _state.value.copy(error = error.message ?: "Unable to scan")
            } finally {
                _state.value = _state.value.copy(scanning = false)
            }
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        scanJob = null
        _state.value = _state.value.copy(scanning = false)
    }

    fun select(address: String) {
        _state.value = _state.value.copy(selectedAddress = address)
    }

    override fun onCleared() {
        stopScan()
        super.onCleared()
    }
}

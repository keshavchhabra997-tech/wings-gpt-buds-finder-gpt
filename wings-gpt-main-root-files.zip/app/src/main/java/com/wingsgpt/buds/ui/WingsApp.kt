package com.wingsgpt.buds.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.wingsgpt.buds.model.AppTab
import com.wingsgpt.buds.ui.components.GlassBottomBar
import com.wingsgpt.buds.ui.screens.*

@Composable
fun WingsApp(vm: WingsViewModel = viewModel()) {
    var introDone by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(AppTab.Home) }

    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(com.wingsgpt.buds.ui.theme.Void, com.wingsgpt.buds.ui.theme.Panel))
    )) {
        AnimatedContent(
            targetState = introDone,
            transitionSpec = {
                fadeIn(tween(650)) togetherWith fadeOut(tween(350))
            },
            label = "app-intro"
        ) { ready ->
            if (!ready) CinematicIntro(onFinished = { introDone = true })
            else {
                val state by vm.state.collectAsState()
                Box(Modifier.fillMaxSize()) {
                    when (tab) {
                        AppTab.Home -> HomeScreen(state, onScan = vm::startScan, onStop = vm::stopScan, onSelect = vm::select)
                        AppTab.Radar -> RadarScreen(state, onScan = vm::startScan)
                        AppTab.Lab -> LabScreen(state)
                        AppTab.Settings -> SettingsScreen()
                    }
                    GlassBottomBar(
                        selected = tab,
                        onSelect = { tab = it },
                        modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter)
                            .padding(start = 18.dp, end = 18.dp, bottom = 22.dp)
                    )
                }
            }
        }
    }
}

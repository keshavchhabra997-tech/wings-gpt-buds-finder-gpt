package com.wingsgpt.buds.model

import java.util.UUID

data class BleObservation(
    val name: String,
    val address: String,
    val rssi: Int,
    val timestamp: Long,
    val serviceUuids: List<UUID>,
    val manufacturerIds: List<Int>
)

data class BudConnection(
    val displayName: String = "keshav ke airpods",
    val isConnected: Boolean = false,
    val lastSeenMillis: Long? = null,
    val rssi: Int? = null
)

enum class AppTab(val label: String) {
    Home("Home"), Radar("Radar"), Lab("Lab"), Settings("Settings")
}

enum class CapabilityState { CONFIRMED, INFERRED, UNKNOWN, UNSUPPORTED }

data class HardwareCapability(
    val title: String,
    val state: CapabilityState,
    val detail: String
)

package com.wingsgpt.buds.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.wingsgpt.buds.ui.theme.Cyan

@Composable
fun SignalBars(level: Int, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "signal-pulse")
    val pulse by infinite.animateFloat(
        initialValue = .65f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse"
    )
    Canvas(modifier.size(70.dp, 36.dp)) {
        val bars = 5
        val gap = size.width * .07f
        val barWidth = (size.width - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val height = size.height * (.25f + i * .17f)
            val active = i < level.coerceIn(0, bars)
            drawRoundRect(
                color = if (active) Cyan.copy(alpha = pulse) else Color.White.copy(alpha = .13f),
                topLeft = androidx.compose.ui.geometry.Offset(i * (barWidth + gap), size.height - height),
                size = androidx.compose.ui.geometry.Size(barWidth, height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2)
            )
        }
    }
}

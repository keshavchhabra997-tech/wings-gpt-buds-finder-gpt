package com.wingsgpt.buds.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.wingsgpt.buds.model.AppTab
import com.wingsgpt.buds.ui.theme.*

@Composable
fun GlassBottomBar(selected: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    val transition = updateTransition(selected, label = "glass-nav")
    val activeIndex by transition.animateFloat(
        transitionSpec = { spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = 0.78f) },
        label = "active-index"
    ) { it.ordinal.toFloat() }

    BoxWithConstraints(
        modifier = modifier.fillMaxWidth().height(76.dp)
            .shadow(28.dp, RoundedCornerShape(30.dp), ambientColor = Cyan.copy(alpha = .13f))
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.verticalGradient(listOf(Color(0xCC343B4A), Color(0xA6121721))))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(.35f), Color.White.copy(.04f))), RoundedCornerShape(30.dp))
            .padding(7.dp)
    ) {
        val itemWidth = maxWidth / AppTab.entries.size
        val pillOffset by animateDpAsState(
            targetValue = itemWidth * activeIndex,
            animationSpec = spring(dampingRatio = .76f, stiffness = 360f),
            label = "pill-offset"
        )
        Box(
            Modifier.offset(x = pillOffset).width(itemWidth).fillMaxHeight()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.verticalGradient(listOf(Color.White.copy(.23f), Color.White.copy(.055f))))
                .border(1.dp, Color.White.copy(.22f), RoundedCornerShape(24.dp))
        )
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            AppTab.entries.forEach { item ->
                val active = selected == item
                val tint by animateColorAsState(
                    if (active) Cyan else Muted,
                    animationSpec = tween(250), label = "nav-tint"
                )
                Column(
                    modifier = Modifier.weight(1f).fillMaxHeight()
                        .clip(RoundedCornerShape(22.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelect(item)
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val icon = when (item) {
                        AppTab.Home -> Icons.Rounded.Home
                        AppTab.Radar -> Icons.Rounded.Radar
                        AppTab.Lab -> Icons.Rounded.Biotech
                        AppTab.Settings -> Icons.Rounded.Settings
                    }
                    Icon(icon, contentDescription = item.label, tint = tint, modifier = Modifier.size(if (active) 23.dp else 21.dp))
                    Spacer(Modifier.height(4.dp))
                    Text(item.label, color = tint, fontSize = 10.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

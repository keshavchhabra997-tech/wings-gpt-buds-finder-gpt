package com.wingsgpt.buds.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wingsgpt.buds.model.CapabilityState
import com.wingsgpt.buds.model.HardwareCapability
import com.wingsgpt.buds.ui.DashboardState
import com.wingsgpt.buds.ui.components.GlassCard
import com.wingsgpt.buds.ui.theme.*

@Composable
fun LabScreen(state: DashboardState) {
    val capabilities = listOf(
        HardwareCapability("BLE advertisement scan", CapabilityState.CONFIRMED, "Android scanner returns real nearby advertisements."),
        HardwareCapability("RSSI signal strength", CapabilityState.CONFIRMED, "Measured from the phone's BLE scan callback."),
        HardwareCapability("TY advertiser identity", CapabilityState.UNKNOWN, "Relationship to the Wings earbuds is not verified."),
        HardwareCapability("Case lid telemetry", CapabilityState.UNKNOWN, "Advertisement correlation is not proof of a lid sensor."),
        HardwareCapability("Left/right battery", CapabilityState.UNKNOWN, "No verified battery protocol."),
        HardwareCapability("Find-bud audio command", CapabilityState.UNSUPPORTED, "No safe, documented command is available.")
    )
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(20.dp, 20.dp, 20.dp, 120.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Hardware lab", color = TextPrimary, fontSize = 27.sp)
            Text("Evidence-based capability report", color = Muted, fontSize = 12.sp)
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("LIVE SESSION", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                Text("${state.observations.size} devices captured", color = TextPrimary, fontSize = 22.sp)
                Text("Scanner state: ${if (state.scanning) "RUNNING" else "STOPPED"}", color = Muted, fontSize = 11.sp)
            }
        }
        items(capabilities.size) { index ->
            val cap = capabilities[index]
            GlassCard(Modifier.fillMaxWidth()) {
                Text(cap.title, color = TextPrimary, fontSize = 15.sp)
                Text(cap.state.name, color = when (cap.state) {
                    CapabilityState.CONFIRMED -> Good
                    CapabilityState.INFERRED -> Cyan
                    CapabilityState.UNKNOWN -> Warning
                    CapabilityState.UNSUPPORTED -> Danger
                }, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Text(cap.detail, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

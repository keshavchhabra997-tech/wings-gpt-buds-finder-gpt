package com.wingsgpt.buds.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import com.wingsgpt.buds.model.BleObservation
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.util.UUID

class BleScanner(private val context: Context) {
    private val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? get() = manager.adapter

    fun isBluetoothAvailable(): Boolean = adapter?.isEnabled == true
    fun isBleSupported(): Boolean = context.packageManager.hasSystemFeature("android.hardware.bluetooth_le")

    @SuppressLint("MissingPermission")
    fun scan(): Flow<BleObservation> = callbackFlow {
        val bluetoothAdapter = adapter
        val scanner = bluetoothAdapter?.bluetoothLeScanner
        if (scanner == null || bluetoothAdapter.isEnabled.not()) {
            close(IllegalStateException("Bluetooth is disabled or BLE scanner is unavailable"))
            return@callbackFlow
        }

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val record = result.scanRecord
                val uuids = record?.serviceUuids.orEmpty().map(ParcelUuid::getUuid)
                val ids = record?.manufacturerSpecificData?.let { data ->
                    (0 until data.size()).map { data.keyAt(it) }
                }.orEmpty()
                val observation = BleObservation(
                    name = result.device.name ?: record?.deviceName ?: "Unknown device",
                    address = result.device.address,
                    rssi = result.rssi,
                    timestamp = System.currentTimeMillis(),
                    serviceUuids = uuids,
                    manufacturerIds = ids
                )
                trySend(observation)
            }

            override fun onScanFailed(errorCode: Int) {
                close(IllegalStateException("BLE scan failed: $errorCode"))
            }
        }

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setReportDelay(0)
            .build()

        try {
            scanner.startScan(null, settings, callback)
        } catch (security: SecurityException) {
            close(security)
        }

        awaitClose {
            try { scanner.stopScan(callback) } catch (_: SecurityException) { }
        }
    }
}

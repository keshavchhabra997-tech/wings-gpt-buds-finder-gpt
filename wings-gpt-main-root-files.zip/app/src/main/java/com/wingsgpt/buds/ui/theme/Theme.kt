package com.wingsgpt.buds.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = Cyan, secondary = Violet, background = Void, surface = Panel,
    onPrimary = Void, onSecondary = Void, onBackground = TextPrimary, onSurface = TextPrimary
)

@Composable
fun WingsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}

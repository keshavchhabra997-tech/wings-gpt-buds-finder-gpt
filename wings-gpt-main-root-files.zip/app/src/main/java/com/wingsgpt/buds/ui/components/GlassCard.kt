package com.wingsgpt.buds.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.dp
import com.wingsgpt.buds.ui.theme.*

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xB52A3140), Color(0x75121822))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.23f), Color.White.copy(.035f))), RoundedCornerShape(26.dp))
            .padding(18.dp),
        content = content
    )
}

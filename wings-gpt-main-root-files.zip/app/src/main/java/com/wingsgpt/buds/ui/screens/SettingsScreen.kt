package com.wingsgpt.buds.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.*
import com.wingsgpt.buds.ui.components.GlassCard
import com.wingsgpt.buds.ui.theme.*

@Composable
fun SettingsScreen() {
    var haptics by remember { mutableStateOf(true) }
    var reducedMotion by remember { mutableStateOf(false) }
    var intro by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", color = TextPrimary, fontSize = 27.sp)
        Text("Personalize your experience", color = Muted, fontSize = 12.sp)
        GlassCard(Modifier.fillMaxWidth()) {
            SettingToggle("Haptic feedback", "Subtle tactile response on interactions", haptics) { haptics = it }
            Divider(color = GlassEdge, modifier = Modifier.padding(vertical = 12.dp))
            SettingToggle("Reduced motion", "Reduce non-essential animation", reducedMotion) { reducedMotion = it }
            Divider(color = GlassEdge, modifier = Modifier.padding(vertical = 12.dp))
            SettingToggle("Cinematic startup", "Show the animated opening sequence", intro) { intro = it }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("ABOUT THIS BUILD", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
            Text("Wings GPT • 1.0.0", color = TextPrimary, fontSize = 17.sp)
            Text("Native Android companion prototype. Hardware capabilities remain subject to verification.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingToggle(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
        Switch(checked, onCheckedChange = onChecked)
    }
}

package com.wingsgpt.buds.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.wingsgpt.buds.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable
fun CinematicIntro(onFinished: () -> Unit) {
    var stage by remember { mutableIntStateOf(0) }
    val infinite = rememberInfiniteTransition(label = "intro")
    val rotation by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "rotation")
    val breathe by infinite.animateFloat(.88f, 1.08f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "breathe")
    val logoAlpha by animateFloatAsState(if (stage >= 1) 1f else 0f, tween(900), label = "logo-alpha")
    val caseScale by animateFloatAsState(if (stage >= 2) 1f else .65f, spring(dampingRatio = .62f), label = "case-scale")
    val titleOffset by animateDpAsState(if (stage >= 3) 0.dp else 22.dp, spring(dampingRatio = .7f), label = "title-offset")

    LaunchedEffect(Unit) {
        delay(250); stage = 1
        delay(850); stage = 2
        delay(850); stage = 3
        delay(1250); onFinished()
    }

    Box(Modifier.fillMaxSize().background(Void), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height * .43f)
            drawCircle(Brush.radialGradient(listOf(Blue.copy(.22f), Color.Transparent), center, size.minDimension * .55f), size.minDimension * .55f, center)
            for (i in 0 until 46) {
                val angle = i * 2.399
                val radius = size.minDimension * (.12f + (i % 9) * .045f)
                val x = center.x + cos(angle + rotation * .002f) * radius
                val y = center.y + sin(angle + rotation * .002f) * radius
                drawCircle(Color.White.copy(alpha = .12f + (i % 4) * .04f), 1.2f + (i % 3), Offset(x, y))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(238.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().rotate(rotation)) {
                    drawCircle(Cyan.copy(.16f), radius = size.minDimension * .48f, style = androidx.compose.ui.graphics.drawscope.Stroke(1.5.dp.toPx()))
                    drawArc(Brush.sweepGradient(listOf(Color.Transparent, Cyan, Violet, Color.Transparent)), 30f, 105f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                }
                Box(Modifier.size(164.dp).scale(caseScale * breathe).clip(androidx.compose.foundation.shape.RoundedCornerShape(48.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF343B49), Color(0xFF10141D))))
                    .border(1.dp, Color.White.copy(.25f), androidx.compose.foundation.shape.RoundedCornerShape(48.dp)),
                    contentAlignment = Alignment.Center) {
                    Text("W", color = Cyan, fontSize = 76.sp, fontWeight = FontWeight.Black)
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("WINGS", color = TextPrimary.copy(alpha = logoAlpha), fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 8.sp)
            Text("B U D S   F I N D E R", color = Muted.copy(alpha = logoAlpha), fontSize = 10.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(26.dp))
            Text("PRECISION. CONNECTION. CONTROL.", color = Color.White.copy(alpha = logoAlpha * .65f), fontSize = 9.sp, letterSpacing = 2.sp)
        }
        TextButton(onClick = onFinished, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp)) {
            Text("SKIP INTRO", color = Muted, letterSpacing = 2.sp, fontSize = 10.sp)
        }
    }
}

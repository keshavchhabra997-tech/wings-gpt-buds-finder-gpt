package com.wingsgpt.buds.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.wingsgpt.buds.model.BleObservation
import com.wingsgpt.buds.ui.DashboardState
import com.wingsgpt.buds.ui.components.*
import com.wingsgpt.buds.ui.theme.*

@Composable
fun HomeScreen(state: DashboardState, onScan: () -> Unit, onStop: () -> Unit, onSelect: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("WINGS", color = Cyan, fontSize = 11.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
                    Text("Your audio, under control.", color = TextPrimary, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(42.dp).clip(CircleShape).background(Glass).border(1.dp, GlassEdge, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Person, null, tint = TextPrimary)
                }
            }
        }
        item { CaseHero(state) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatusTile("LEFT BUD", "Unverified", Icons.Rounded.Headphones, Modifier.weight(1f))
                StatusTile("RIGHT BUD", "Unverified", Icons.Rounded.Headphones, Modifier.weight(1f))
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("BLUETOOTH RADAR", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        Text(if (state.scanning) "Scanning nearby devices" else "Ready to scan", color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                    SignalBars(if (state.scanning) 4 else 1)
                }
                Spacer(Modifier.height(14.dp))
                Button(onClick = { if (state.scanning) onStop() else onScan() }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Void)) {
                    Icon(if (state.scanning) Icons.Rounded.Stop else Icons.Rounded.Radar, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (state.scanning) "STOP SCAN" else "START REAL BLE SCAN", fontWeight = FontWeight.Bold)
                }
                state.error?.let { Text(it, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Nearby devices", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("${state.observations.size} found", color = Muted, fontSize = 12.sp)
            }
        }
        items(state.observations, key = { it.address }) { item -> DeviceRow(item, state.selectedAddress == item.address) { onSelect(item.address) } }
        if (state.observations.isEmpty()) item { EmptyState() }
    }
}

@Composable
private fun CaseHero(state: DashboardState) {
    val infinite = rememberInfiniteTransition(label = "case-float")
    val float by infinite.animateFloat(-5f, 5f, infiniteRepeatable(tween(2300), RepeatMode.Reverse), label = "float")
    Box(Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(30.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF1A2534), Color(0xFF11121C), Color(0xFF251A36))))
        .border(1.dp, Color.White.copy(.12f), RoundedCornerShape(30.dp))) {
        Box(Modifier.align(Alignment.TopEnd).offset(x = 55.dp, y = (-60).dp).size(190.dp).background(Blue.copy(.10f), CircleShape).blur(38.dp))
        Column(Modifier.align(Alignment.TopStart).padding(20.dp)) {
            Text("DEVICE OVERVIEW", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            Text("Your Buds", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Hardware telemetry pending", color = Warning, fontSize = 11.sp)
        }
        Box(Modifier.align(Alignment.Center).offset(y = (float).dp).size(128.dp, 94.dp)
            .clip(RoundedCornerShape(30.dp)).background(Brush.verticalGradient(listOf(Color(0xFF485262), Color(0xFF171C27))))
            .border(1.dp, Color.White.copy(.28f), RoundedCornerShape(30.dp)), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxWidth().height(3.dp).align(Alignment.TopCenter).background(Cyan.copy(.6f)))
            Text("W", color = Cyan, fontSize = 46.sp, fontWeight = FontWeight.Black)
        }
        Text("CASE • MODEL UNVERIFIED", color = Muted, fontSize = 9.sp, letterSpacing = 1.4.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(20.dp))
        Text("3D MODEL PREVIEW", color = Cyan.copy(.8f), fontSize = 9.sp,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp))
    }
}

@Composable
private fun StatusTile(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    GlassCard(modifier) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(23.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
        Text(value, color = Warning, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun DeviceRow(item: BleObservation, selected: Boolean, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Bluetooth, null, tint = if (selected) Cyan else Muted, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(item.address, color = Muted, fontSize = 10.sp)
                Text("RSSI ${item.rssi} dBm • ${item.serviceUuids.size} services", color = Cyan, fontSize = 10.sp)
            }
            if (selected) Icon(Icons.Rounded.CheckCircle, null, tint = Good)
        }
    }
}

@Composable
private fun EmptyState() {
    GlassCard(Modifier.fillMaxWidth()) {
        Icon(Icons.Rounded.Radar, null, tint = Muted, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(8.dp))
        Text("No scan results yet", color = TextPrimary, fontWeight = FontWeight.SemiBold)
        Text("Start a BLE scan to discover nearby advertisers.", color = Muted, fontSize = 12.sp)
    }
}

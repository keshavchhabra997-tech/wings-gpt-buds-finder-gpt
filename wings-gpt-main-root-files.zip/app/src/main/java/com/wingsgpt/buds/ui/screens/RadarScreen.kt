package com.wingsgpt.buds.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.wingsgpt.buds.ui.DashboardState
import com.wingsgpt.buds.ui.components.GlassCard
import com.wingsgpt.buds.ui.theme.*
import kotlin.math.*

@Composable
fun RadarScreen(state: DashboardState, onScan: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "radar")
    val sweep by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "sweep")
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Signal radar", color = TextPrimary, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Live BLE observations • no directional ranging", color = Muted, fontSize = 12.sp)
        GlassCard(Modifier.fillMaxWidth().height(350.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2, size.height / 2)
                val r = min(size.width, size.height) * .43f
                for (i in 1..4) drawCircle(Cyan.copy(alpha = .10f), r * i / 4f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
                drawLine(Cyan.copy(.18f), Offset(c.x-r,c.y), Offset(c.x+r,c.y), 1.dp.toPx())
                drawLine(Cyan.copy(.18f), Offset(c.x,c.y-r), Offset(c.x,c.y+r), 1.dp.toPx())
                drawArc(Brush.sweepGradient(listOf(Color.Transparent, Cyan.copy(.35f), Color.Transparent)), sweep, 65f, true,
                    topLeft = Offset(c.x-r,c.y-r), size = androidx.compose.ui.geometry.Size(r*2,r*2))
                state.observations.take(12).forEachIndexed { index, item ->
                    val angle = index * 2.4
                    val radius = r * (.25 + (index % 4) * .16)
                    drawCircle(Violet.copy(.85f), 5.dp.toPx(), Offset(c.x + cos(angle)*radius, c.y + sin(angle)*radius))
                }
                drawCircle(Cyan, 4.dp.toPx(), c)
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("${state.observations.size} advertisers observed", color = TextPrimary, fontWeight = FontWeight.Bold)
            Text("Radar positions are decorative distribution, not physical direction or distance.", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onScan, modifier = Modifier.fillMaxWidth()) { Text("START BLE SCAN") }
        }
    }
}

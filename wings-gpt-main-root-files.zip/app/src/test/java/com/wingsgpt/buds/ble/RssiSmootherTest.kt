package com.wingsgpt.buds.ble

import org.junit.Assert.assertEquals
import org.junit.Test

class RssiSmootherTest {
    @Test fun averagesRecentSamples() {
        val smoother = RssiSmoother(3)
        smoother.add(-60)
        smoother.add(-50)
        assertEquals(-55, smoother.add(-40))
    }

    @Test fun discardsOldestSampleWhenWindowIsFull() {
        val smoother = RssiSmoother(2)
        smoother.add(-90)
        smoother.add(-60)
        assertEquals(-50, smoother.add(-40))
        assertEquals(listOf(-60, -40), smoother.snapshot())
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsEmptyWindow() {
        RssiSmoother(0)
    }
}

# Wings GPT — Buds Finder

Native Kotlin + Jetpack Compose Android project.

## Current implementation
- Cinematic animated startup with skip control.
- Liquid-glass inspired animated bottom navigation.
- Dark dashboard and device overview.
- BLE scan flow with live observations, service UUIDs, manufacturer IDs and RSSI smoothing.
- Radar visualization using actual scan count but deliberately non-directional placement.
- Evidence-based hardware capability lab.
- Settings for haptics/reduced motion/startup preferences (UI preferences currently local to screen state).
- Unit tests for RSSI smoothing.
- GitHub Actions build and test workflow.

## Important hardware limits
This build does not claim battery telemetry, left/right bud detection, lid telemetry, GPS tracking or audio commands. The `TY` advertiser has not been proven to belong to the earbuds. No undocumented GATT writes are performed.

## Build
Requires JDK 17 and Android SDK 35.

```bash
gradle assembleDebug
gradle testDebugUnitTest
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Android permissions
Android 12+ requires `BLUETOOTH_SCAN`; `BLUETOOTH_CONNECT` is declared for future connection inspection. Runtime permission request UI must be granted before scanning. On Android 11 and lower, location permission is required for BLE scanning.

## Repository
Suggested GitHub repository name: `wings-gpt-buds-finder`.
